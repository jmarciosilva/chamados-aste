<div class="bg-white p-4 rounded shadow">
    <p class="text-xs text-slate-500">{{ $label }}</p>
    <p class="font-medium">{{ $value }}</p>
</div>
